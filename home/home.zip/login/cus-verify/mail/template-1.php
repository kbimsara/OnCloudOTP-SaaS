
<?php

class template
{
    var $url="./";
    var $otp;
    var $timeStamp;

    function view()
    {
        $temp = '
        <!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    
    body, table, td, a {
      font-family: poppins, SF Pro Display;
      font-size: 14px;
      line-height: 1.4;
      color: #333333;
    }

   
    .wrapper {
      width: 100%;
      max-width: 600px;
      margin: 0 auto;
    }
    
    
    .header {
      background-color: #f5f5f5;
      padding: 20px;
      text-align: center;
      font-family: poppins;
      color: #6e6e6e;
    }
    
    
    .content {
      padding: 40px;
      background-color: #ffffff;
      
    }
    
    
    
    .otp-code {
        
      font-size: 32px;  
      font-weight: bold;
      text-align: center;
      margin-bottom: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      border: 2px solid #000000;
      padding: 5px;
      border-radius: 10px;
      width: fit-content;
      margin-left: auto;
      margin-right: auto;
      
    }

    
    /* Timer eka*/
    .countdown {
      text-align: center;
      font-size: 20px;
      margin-bottom: 20px;
    }
    
    
    .centeredtxt {
      text-align: center;
    }
    
   
    .logo {
      text-align: center;
      margin-bottom: 20px;
    }
    
    .logo img {
      max-width: 170px;
      height: auto;
    }
    .logo-2 img {
        height: auto;
        max-width: 100px;
    }
    .mail-icon img{
        max-width: 250px;
        height: auto;
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    
    
    
    .footer {
      background-color: #f5f5f5;
      padding: 20px;
      text-align: center;
      font-size: 12px;
      color: #777777;
    }
    
    /* Expired Message eka*/
    .expired-message {
      color: red;
      text-align: center;
      margin-top: 10px;
    }
    .boldtxt{
        font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="header">
        <div class="logo">
           <img src="https://oncloudotp.kbxwebx-test.top/login/mail/img-email/LOGOdark.png" alt="Company Logo"> <!--  Company ye logo eka -->
        </div>
      <h2>One-Time Password</h2>
    </div>
    
    <div class="content">
       <div class="mail-icon">
           <img src="https://oncloudotp.kbxwebx-test.top/login/mail/img-email/mail.gif" alt="Company Logo 2">  <!-- mail illustration eka -->
       </div>
      
      <p class="centeredtxt boldtxt"> Your One-Time Password (OTP) is:</p>
      <div class="otp-code">'.$this->otp.'</div> <!-- OTP eka -->
      <p class="centeredtxt boldtxt">Please use this code to verify your account.</p>
      <p class="centeredtxt">This OTP code will expire in:</p>
      <div class="countdown" id="countdown">5:00</div> <!-- timmer 5min -->
      
      <div class="expired-message" id="expired-message"></div>
    </div>
    <div class="footer">
      <p>This email was sent to you as part of the account verification process. If you didnt request this OTP, please ignore this email.</p>
      <p class="centeredtxt">Powered by</p>
        <div class="logo-2">
           <img src="https://oncloudotp.kbxwebx-test.top/login/mail/img-email/LOGOdark.png" alt="Company Logo 2"><!--  ape company logo eka -->
        </div>

    </div>
  </div>

  <script>
    // Countdown Timer eka 5min
    var countdownElement = document.getElementById("countdown");
    var expiredMessageElement = document.getElementById("expired-message");
    var countdownTime = 5 * 60; //Need replace current time stamp

    function countdown() {
      var minutes = Math.floor(countdownTime / 60);
      var seconds = countdownTime % 60;

      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      countdownElement.innerHTML = minutes + ":" + seconds;

      if (countdownTime > 0) {
        countdownTime--;
        setTimeout(countdown, 1000);
      } else {
        countdownElement.style.color = "red";
        document.querySelector(".otp-code").style.color = "red";
        expiredMessageElement.innerHTML = "OTP has expired.";
      }
    }

    countdown();
  </script>
</body>
</html>
';
        return $temp;
    }
}

?>

